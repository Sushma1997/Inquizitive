

import xlrd 
from main import db
from main import english,science,social
from flask_sqlalchemy import SQLAlchemy

loc=("dataset.xlsx")

wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 

for i in range(1,sheet.nrows):
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	if(sheet.cell_value(i,1)=='English Literature'):
		sql='insert into english(question,answer) values(?,?)'
		p=[]
		q=sheet.cell_value(i,3)
		q=q.replace('\xa0',' ')
		p.append(q)
		s=sheet.cell_value(i,4)
		s=s.replace('\xa0',' ')
		p.append(s)
		cursor.execute(sql,p)
		connection.commit()
	elif(sheet.cell_value(i,1)=='Science'):
		sql='insert into science(question,answer) values(?,?)'
		p=[]
		q=sheet.cell_value(i,3)
		q=q.replace('\xa0',' ')
		p.append(q)
		s=sheet.cell_value(i,4)
		s=s.replace('\xa0',' ')
		p.append(s)
		cursor.execute(sql,p)
		connection.commit()
	elif(sheet.cell_value(i,1)=='social'):
		sql='insert into social(question,answer) values(?,?)'
		p=[]
		q=sheet.cell_value(i,3)
		q=q.replace('\xa0',' ')
		p.append(q)
		s=sheet.cell_value(i,4)
		s=s.replace('\xa0',' ')
		p.append(s)
		cursor.execute(sql,p)
		connection.commit()
		
		
"""
from main import db
from main import english,science

connection = db.engine.raw_connection()
cursor=connection.cursor()
s='delete from science'
cursor.execute(s)
connection.commit()

s='delete from english'
cursor.execute(s)
connection.commit()
"""