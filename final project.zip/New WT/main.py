from flask import Flask,render_template,url_for
from flask_sqlalchemy import SQLAlchemy
from flask import request,redirect
from flask import jsonify
import json
from flask import session
#from flask.ext.session import Session
import os
from sqlalchemy import text
from sqlalchemy.orm import load_only
import random
import simplejson
from decimal import Decimal
from SentenceSimilarity import finalScore

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///inquisitive.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key=os.urandom(24)

cq='0'
		   
db = SQLAlchemy(app)



class user(db.Model):
   __tablename__='user'
   username = db.Column(db.String(50), primary_key = True)
   name = db.Column(db.String(50),nullable=False)
   email = db.Column(db.String(50),nullable=False)  
   password = db.Column(db.String(20),nullable=False)
   phoneno= db.Column(db.Integer,nullable=False)
   score = db.Column(db.Numeric(10,4),default=0.0)
   
   
class english(db.Model):
	__tablename__='english'
	id = db.Column(db.Integer, primary_key=True)
	question=db.Column(db.String(1000),nullable=False)
	answer=db.Column(db.String(10000),nullable=False)

class science(db.Model):
	__tablename__='science'
	id = db.Column(db.Integer, primary_key=True)
	question=db.Column(db.String(1000),nullable=False)
	answer=db.Column(db.String(10000),nullable=False)
	
class social(db.Model):
	__tablename__='social'
	id = db.Column(db.Integer, primary_key=True)
	question=db.Column(db.String(1000),nullable=False)
	answer=db.Column(db.String(10000),nullable=False)
	
class quizdb(db.Model):
	__tablename__='quizdb'
	id = db.Column(db.Integer, primary_key=True)
	q_id=db.Column(db.Integer,nullable=False)
	question=db.Column(db.String(1000),nullable=False)
	answer=db.Column(db.String(10000),default='')
	score=db.Column(db.Numeric(10,4),default=0.0)
  
@app.route('/')
def home():
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	sql="Delete from quizdb"
	param=[]
	cursor.execute(sql,param)
	connection.commit()
	return render_template('/home/mainpage.html')

@app.route('/login')	
def login():
	return render_template('/login and sign up/html/login.html',title='Login')

@app.route('/signup')	
def sign_up():
	return render_template('/login and sign up/html/sign_up.html',title='Sign up')
	
@app.route('/unamecheck', methods=['GET'])
def unamecheck():
	username = request.args.get('uname')
	un=user.query.filter_by(username=username).all()
	if(len(un)==1):
		res={'status':1}
	else :
		res={'status':0}
	print(res)
	return jsonify(res)
	
@app.route('/validate', methods=['POST'])
def validate():
	username = request.form['uname']
	pwd = request.form['pwd']
	un=user.query.filter_by(username=username,password=pwd).all()
	if(len(un)==1):
		session['uname']=username
		print(session['uname'])
		res={'status':1}
	else :
		res={'status':0}
	print(res)
	return jsonify(res)	
	
@app.route('/insert', methods=['POST'])
def insert():
	uname = request.form['uname']
	pw = request.form['pass']	
	email = request.form['email']	
	pn = request.form['pno']	
	fn = request.form['fname']	
	
	session['uname']=uname
	o=user(username=uname,name=fn,email=email,password=pw,phoneno=pn)
	print(o)
	db.session.add(o)
	db.session.commit()
	
	return redirect('/dashboard')
	
@app.route('/dashboard')
def dash():
	if 'uname' in session:
		return render_template('/quiz/pages/dashboard.html')
	else:
		return redirect('/')
		
		
@app.route('/profile')
def profile():
	if 'uname' in session:
		return render_template('/quiz/pages/profile.html')
	else:
		return redirect('/')

	
@app.route('/leaderboard')
def leaderboard():
	
	sql = text('Select sc.score, (Select Count(1) + 1 From (Select Distinct score from user) as uniqeScores where score > sc.score) as rank ,sc.username From user sc Order by sc.score Desc limit 5')	
	result = db.engine.execute(sql)	
	names = []
	for row in result:
		names.append([row[1],row[0],row[2]])

	#print(names)	
	x=jsonify(names)
	#print(x)
	return x
	
@app.route('/userscore')
def userscore():
	if 'uname' in session:
		sc=user.query.filter_by(username=session['uname']).options(load_only('score')).first()
		print(simplejson.dumps(sc.score))
		return simplejson.dumps(sc.score)
	else:
		return redirect('/')

@app.route('/userrank')
def userrank():
	if 'uname' in session:
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Select sc.score, (Select Count(1) + 1 From (Select Distinct score from user) as uniqeScores where score > sc.score) as rank ,sc.username From user sc where sc.username=? Order by sc.score Desc"
		param=[]
		param.append(session['uname'])
		cursor.execute(sql,param)
		x=cursor.fetchall()
		#print(x[0][1])
		return jsonify(x[0][1])
	else:
		return redirect('/')
	
@app.route('/logout')
def logout():
	session.pop('uname')
	return redirect('/')

@app.route('/oldpassword')
def oldpass():
	if 'uname' in session:
		sc=user.query.filter_by(username=session['uname']).options(load_only('password')).first()
		print(sc.password)
		pwd = request.args.get('pwd')
		if(sc.password==pwd):
			res={'status':1}
		else:
			res={'status':0}
		
		return jsonify(res)
	else:
		return redirect('/')
	
	
@app.route('/oldemail')
def oldemail():
	if 'uname' in session:
		sc=user.query.filter_by(username=session['uname']).options(load_only('email')).first()
		print(sc.email)
		email = request.args.get('email')
		if(sc.email==email):
			res={'status':1}
		else:
			res={'status':0}
		
		return jsonify(res)
	else:
		return redirect('/')
		
@app.route('/newpassword',methods=['POST'])
def npwd():
	if 'uname' in session:
		pwd = request.form['pwd']
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Update user set password=? where username=?"
		param=[]
		param.append(pwd)
		param.append(session['uname'])
		cursor.execute(sql,param)
		connection.commit()
		res={'status':1}
		return jsonify(res)
	else:
		return redirect('/')
		
@app.route('/newemail',methods=['POST'])
def nemail():
	if 'uname' in session:
		email = request.form['email']
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Update user set email=? where username=?"
		param=[]
		param.append(email)
		param.append(session['uname'])
		cursor.execute(sql,param)
		connection.commit()
		res={'status':1}
		return jsonify(res)
	else:
		return redirect('/')

@app.route('/quiz')		
def quiz():
	if 'uname' in session:
		global cq
		cq=request.args.get('quiz')
		return render_template('/quiz/pages/quiz.html')
	else:
		return redirect('/')
		
		
@app.route('/question_generate')
def question_generate():
	if 'uname' in session:
				
		global cq
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Delete from quizdb"
		param=[]
		cursor.execute(sql,param)
		connection.commit()
		fl=[]
		if cq=='1':
			return eng()
		elif cq=='2':
			return sci()
		elif cq=='3':
			return soc()
	else:
		return redirect('/')
			
def eng():
	fl=[]
	ql=random.sample(range(1,51),20)
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	for i in range(20):
		sql="select question from english where id=?"
		tp=[]
		param=[]
		param.append(ql[i])		
		cursor.execute(sql,param)
		x=cursor.fetchall()
		tp.append(i)
		tp.append(x[0][0])
			
		s="insert into quizdb('q_id','question') values(?,?)"
		p=[]
		p.append(ql[i])
		p.append(x[0][0])
		cursor.execute(s,p)
		connection.commit()
		
		fl.append(tp)	

	print(fl)
	return jsonify(fl)

def sci():
	fl=[]
	ql=random.sample(range(1,21),20)
	print(ql)
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	for i in range(20):
		sql="select question from science where id=?"
		tp=[]
		param=[]
		param.append(ql[i])	
		print(ql[i])		
		cursor.execute(sql,param)
		x=cursor.fetchall()
		tp.append(i)
		tp.append(x[0][0])
			
		s="insert into quizdb('q_id','question') values(?,?)"
		p=[]
		p.append(ql[i])
		p.append(x[0][0])
		cursor.execute(s,p)
		connection.commit()
		
		fl.append(tp)	

	print(fl)
	return jsonify(fl)
	
def soc():
	fl=[]
	ql=random.sample(range(1,21),20)
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	for i in range(20):
		sql="select question from social where id=?"
		tp=[]
		param=[]
		param.append(ql[i])		
		cursor.execute(sql,param)
		x=cursor.fetchall()
		tp.append(i)
		tp.append(x[0][0])
			
		s="insert into quizdb('q_id','question') values(?,?)"
		p=[]
		p.append(ql[i])
		p.append(x[0][0])
		cursor.execute(s,p)
		connection.commit()
		
		fl.append(tp)	

	print(fl)
	return jsonify(fl)
		
	
		
		
@app.route('/storeanswer',methods=['POST'])
def storeanswer():
	if 'uname' in session:		
		qid=request.form['qid']
		ans=request.form['ans']
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Update quizdb set answer=? where id=?"
		param=[]
		param.append(ans)
		param.append(qid)
		cursor.execute(sql,param)
		connection.commit()
		res={'status':1}
		return jsonify(res)
	else:
		return redirect('/')

@app.route('/retrieveanswer')
def retrieveanswer():		
	if 'uname' in session:		
		qid=request.args.get('qid')
		connection = db.engine.raw_connection()
		cursor=connection.cursor()
		sql="Select answer from quizdb where id=?"
		param=[]
		param.append(qid)
		cursor.execute(sql,param)
		x=cursor.fetchall()
		res=x[0][0]
		print(res)
		return jsonify(res)

	else:
		return redirect('/')
		
		
@app.route('/calculatescore')
def calculatescore():
	totalscore=0
	connection = db.engine.raw_connection()
	cursor=connection.cursor()
	
	for i in range(1,21):
		
		sql="select q_id,answer from quizdb where id=?"
		p=[]
		p.append(i)
		cursor.execute(sql,p)
		x=cursor.fetchall()
		a1=x[0][1]
		q=x[0][0]
		print("x[] ",a1)
		if x[0][1] is None:
			print("null")
			sc=0
		else:
			if(cq=='1'):
				sql="select answer from english where id=?"
				p=[]
				p.append(q)
				cursor.execute(sql,p)
				x=cursor.fetchall()
				a2=x[0][0]
				print("a1 ",a1)
				print("a2 ",a2)
				sc=finalScore(a1,a2)
				totalscore=totalscore+sc
				print("sc ",sc)
				sql="Update quizdb set score=? where id=?"
				p=[]
				p.append(sc)
				p.append(i)
				cursor.execute(sql,p)
				connection.commit()
				
			elif(cq=='2'):
				sql="select answer from science where id=?"
				p=[]
				p.append(q)
				cursor.execute(sql,p)
				x=cursor.fetchall()
				a2=x[0][0]
				sc=finalScore(a1,a2)
				totalscore=totalscore+sc
				
				sql="Update quizdb set score=? where id=?"
				p=[]
				p.append(sc)
				p.append(i)
				cursor.execute(sql,p)
				connection.commit()
			elif(cq=='3'):
				sql="select answer from social where id=?"
				p=[]
				p.append(q)
				cursor.execute(sql,p)
				x=cursor.fetchall()
				a2=x[0][0]
				sc=finalScore(a1,a2)
				totalscore=totalscore+sc
				
				sql="Update quizdb set score=? where id=?"
				p=[]
				p.append(sc)
				p.append(i)
				cursor.execute(sql,p)
				connection.commit()	
	
	#previous score
	sql="select score from user where username=?"
	p=[]
	p.append(session['uname'])
	cursor.execute(sql,p)
	x=cursor.fetchall()
	a=x[0][0]
	
	ts=totalscore+a
	
	#update score
	sql="Update user set score=? where username=?"
	p=[]
	p.append(ts)
	p.append(session['uname'])
	cursor.execute(sql,p)
	connection.commit()
	
	#new rank
	sql="Select sc.score, (Select Count(1) + 1 From (Select Distinct score from user) as uniqeScores where score > sc.score) as rank ,sc.username From user sc where sc.username=? Order by sc.score Desc"
	param=[]
	param.append(session['uname'])
	cursor.execute(sql,param)
	x=cursor.fetchall()
	rank=x[0][1]
	
	res={'sc':totalscore,'ts':ts,'nr':rank}
	return simplejson.dumps(res)


		
db.create_all()	

if __name__ =='__main__' :
	app.run(debug=True)