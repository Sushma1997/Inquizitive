var modal = document.getElementById('myModal');
var modal1 = document.getElementById('myModal1');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");
var btn1 = document.getElementById("myBtn1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
var span1 = document.getElementsByClassName("close1")[0];

// When the user clicks the button, open the modal 
btn.onclick = function(event) {
	
    modal.style.display = "block";
}

btn1.onclick = function(event) {
	
    modal1.style.display = "block";
	
}

// When the user clicks on <span> (x), close the modal
span.onclick = function(event) {
	
        modal.style.display = "none";
}
span1.onclick = function(event) {
 
        modal1.style.display = "none";
}


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
	

    if (event.target == modal) {
        modal.style.display = "none";
    }
	else if (event.target == modal1) {
        modal1.style.display = "none";
    }
}

pemailb=0;
nemailb=0;

ppwdb=0;
npwdb=0;





function clear(temp)
{
	temp.style.visibility="hidden";
	temp.innerHTML="";
	
}

var o1={
		
		xhr:new XMLHttpRequest(),
		
		checkop:function(){
			var ppwd=document.getElementById("ppwd").value;
			if(ppwd!=""){
				console.log("h1");
			this.xhr.onreadystatechange=this.opstatus;
			this.xhr.open("GET","/oldpassword?pwd="+ppwd,true);
			this.xhr.send();
			}
		},
		opstatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==1)
				{	console.log("h2");
					var h=document.getElementById("h1");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="Valid password </br>";
					ppwdb=1;
					setTimeout(clear,2500,h);
					
				}
				else
				{
					console.log("h3");
					var h=document.getElementById("h1");
					h.style.visibility="visible";
					h.style.color="red";
					h.innerHTML="Invalid password </br>";
					ppwdb=0
					setTimeout(clear,2500,h);
				}	
					
			}
		}	
	}
	
	
var o2={
		
		xhr1:new XMLHttpRequest(),
		
		checkoe:function(){
			var pemail=document.getElementById("pemail").value;
			if(pemail!=""){
				console.log("h1");
			this.xhr1.onreadystatechange=this.oestatus;
			this.xhr1.open("GET","/oldemail?email="+pemail,true);
			this.xhr1.send();
			}
		},
		oestatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==1)
				{	console.log("h2");
					var h=document.getElementById("h3");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="Valid email</br>";
					pemailb=1;
					setTimeout(clear,2500,h);
					
				}
				else
				{
					console.log("h3");
					var h=document.getElementById("h3");
					h.style.visibility="visible";
					h.style.color="red";
					h.innerHTML="Invalid email </br>";
					pemailb=0;
					setTimeout(clear,2500,h);
				}	
					
			}
		}	
}

var o3={
		
		xhr2:new XMLHttpRequest(),
		
		enterpwd:function(){
			var npwd=document.getElementById("npwd").value;
			if(npwd!=""){
				console.log("h1");
			this.xhr2.onreadystatechange=this.npstatus;
			this.xhr2.open("POST","/newpassword",true);
			this.xhr2.setRequestHeader("Content-type","application/x-www-form-urlencoded")
			this.xhr2.send("pwd="+npwd);
			}
		},
		npstatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==1)
				{	console.log("h2");
					modal.style.display = "none";
					var h=document.getElementById("a1");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="  Password updated ";
					
					setTimeout(clear,2500,h);
					
				}
				
			}
		}	
}

var o4={
		
		xhr3:new XMLHttpRequest(),
		
		enteremail:function(){
			var nemail=document.getElementById("nemail").value;
			if(nemail!=""){
				console.log("h1");
			this.xhr3.onreadystatechange=this.nestatus;
			this.xhr3.open("POST","/newemail",true);
			this.xhr3.setRequestHeader("Content-type","application/x-www-form-urlencoded")
			this.xhr3.send("email="+nemail);
			}
		},
		nestatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==1)
				{	console.log("h2");
					modal1.style.display = "none";
					var h=document.getElementById("a2");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="  Email updated ";
					setTimeout(clear,2500,h);
					
				}
				
			}
		}	
}
	
	
function checknp()
{
	pwd=document.getElementById("npwd").value;
	var h=document.getElementById("h2");
	if(pwd.length>=8 && pwd.length<=15)
	{
			clear(h);
			npwdb=1;
	}
	else if(pwd.length<8 || pwd.length>15)
	{
		
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="Password should have mininmum 8 characters and maximum 15 characters</br>";
		npwdb=0;
	}
	
	
}

function checkne()
{
	email = document.getElementById('nemail').value;
	
	var re = /\S+@\S+\.\S+/;
	if(!(re.test(email))){
			
			check = document.getElementById("h4");
			check.style.visibility="visible";
			check.innerHTML = " Enter a valid email</br>";
			check.style.color = 'red';
			nemailb=0;
			setTimeout(clear,2500,check);
	}
	else{
		nemailb=1;
	}

}

function validatepwd()
{
	npwd=document.getElementById("npwd");
	ppwd=document.getElementById("ppwd");

	if(ppwd.value=="")
	{	console.log("here");
		var h=document.getElementById("h1");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="Enter your old password";
		setTimeout(clear,2500,h);
		
	
	}
	else if(npwd.value=="")
	{
		var h=document.getElementById("h2");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="Enter your new password";
		setTimeout(clear,2500,h);		
	
	}
	else if(ppwdb==0)
	{
			check = document.getElementById("h1");
			check.style.visibility="visible";
			check.innerHTML = "Enter valid old password";
			check.style.color = 'red';
			setTimeout(clear,2500,check);
	}
	else if(npwdb==0)
	{
			check = document.getElementById("h2");
			check.style.visibility="visible";
			check.innerHTML = "Enter valid password";
			check.style.color = 'red';
			setTimeout(clear,2500,check);
	}
	else
	{
		
		o3.enterpwd();
	}

}

function validatemail()
{
	nemail=document.getElementById("nemail");
	pemail=document.getElementById("pemail");

	if(pemail.value=="")
	{	console.log("here");
		var h=document.getElementById("h3");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="Enter your old email";
		setTimeout(clear,2500,h);
		
	
	}
	else if(nemail.value=="")
	{
		var h=document.getElementById("h4");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="Enter your new email";
		setTimeout(clear,2500,h);		
	
	}
	else if(pemailb==0)
	{
			check = document.getElementById("h3");
			check.style.visibility="visible";
			check.innerHTML = "Enter valid old email";
			check.style.color = 'red';
			setTimeout(clear,2500,check);
	}
	else if(nemailb==0)
	{
			check = document.getElementById("h4");
			check.style.visibility="visible";
			check.innerHTML = "Enter valid email";
			check.style.color = 'red';
			setTimeout(clear,2500,check);
	}
	else
	{
		o4.enteremail();
	}

}
