
function clear(temp)
{
	temp.style.visibility="hidden";
	temp.innerHTML="";
	
}

var o1={
		
		xhr:new XMLHttpRequest(),
		
		checkusername:function(){
			var uname=document.getElementById("uname").value;
			if(uname!=""){
				console.log("h1");
			this.xhr.onreadystatechange=this.unamestatus;
			this.xhr.open("GET","/unamecheck?uname="+uname,true);
			this.xhr.send();
			}
		},
		unamestatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==1)
				{	console.log("h2");
					var h=document.getElementById("hdiv1");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="</br>	Valid user name";
					setTimeout(clear,2500,h);
					
				}
				else
				{
					console.log("h3");
					var h=document.getElementById("hdiv1");
					h.style.visibility="visible";
					h.style.color="red";
					h.innerHTML="</br>	Invalid user name";
					setTimeout(clear,2500,h);
				}	
					
			}
		}	
	}
	
	
var o2={
				
		xhr1:new XMLHttpRequest(),
	
		validatedetails:function(){
			var uname=document.getElementById("uname").value;
			var pwd=document.getElementById("pass").value;
			this.xhr1.onreadystatechange=this.checkstatus;
			this.xhr1.open("POST","/validate",true);
			this.xhr1.setRequestHeader("Content-type","application/x-www-form-urlencoded")
			this.xhr1.send("uname="+uname+"&pwd="+pwd);
			
			
		},
		checkstatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				if(resJSON.status==1)
				{
					window.location="/dashboard";
					
				}
				else
				{
					var h=document.getElementById("hdiv3");
					h.style.visibility="visible";
					h.style.color="red";
					h.innerHTML=" </br>	Invalid user name or password";
					setTimeout(clear,2500,h);
				}
				
			
			}
		}
	
	
	}


function validate()
{
		uname=document.getElementById("uname").value;
		pwd=document.getElementById("pass").value;
		console.log("here");
	
		if(uname=="")
		{
			var h=document.getElementById("hdiv1");
			h.style.visibility="visible";
			h.style.color="red";
			h.innerHTML="</br>	Enter user name";
			setTimeout(clear,2500,h);
		}
		else if(pass=="")
		{
			var h=document.getElementById("hdiv2");
			h.style.visibility="visible";
			h.style.color="red";
			h.innerHTML="</br>	Enter password";
			setTimeout(clear,2500,h);
		}

		else 
		{
			o2.validatedetails();
			
		}
}
