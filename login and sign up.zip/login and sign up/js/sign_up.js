emailb=0;
unameb=0;
pwdb=0;

function clear(temp)
{
	temp.style.visibility="hidden";
	temp.innerHTML="";
	
}

function validate()
{
	uname=document.getElementById("uname");
	fname=document.getElementById("fname");
	email=document.getElementById("email");
	pno=document.getElementById("pno");
	pwd=document.getElementById("pass");

	console.log(fname.value);
	console.log(uname.value);
	console.log(email.value);
	console.log(pno.value);
	console.log(pwd.value);
	if(fname.value=="")
	{	console.log("here");
		var h=document.getElementById("hdiv1");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> Enter your name";
		setTimeout(clear,2500,h);
		
	
	}
	else if(uname.value=="")
	{
		var h=document.getElementById("hdiv2");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> Enter user name";
		setTimeout(clear,2500,h);
		
	
	}
	else if(email.value=="")
	{
		var h=document.getElementById("hdiv3");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> Enter email id";
		setTimeout(clear,2500,h);

	}
	else if(pno.value=="")
	{
		var h=document.getElementById("hdiv4");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> Enter Phone No.";
		setTimeout(clear,2500,h);
	}
	else if(pass.value=="")
	{
		var h=document.getElementById("hdiv5");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> Enter password";
		setTimeout(clear,2500,h);
	}
	else if(unameb==0)
	{
		var h=document.getElementById("hdiv2");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br> User name exists";
		setTimeout(clear,2500,h);
	}
	else if(emailb==0)
	{
			check = document.getElementById("hdiv3");
			check.innerHTML = "</br> Enter a valid email";
			check.style.color = 'red';
			setTimeout(clear,2500,check);
	}
	else if(pwdb==0)
	{
		var h=document.getElementById("hdiv5");
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br>Password should have mininmum 8 characters and maximum 15 characters";
		setTimeout(clear,2500,h);
		
	}
	else
	{
		var f=document.getElementById("signupform");
		f.submit();
	}

}


function validateEmail()
{
	email = document.getElementById('email').value;
	console.log(email);
	var re = /\S+@\S+\.\S+/;
	if(!(re.test(email))){
			console.log(email);
			check = document.getElementById("hdiv3");
			check.style.visibility="visible";
			check.innerHTML = "</br> Enter a valid email";
			check.style.color = 'red';
			emailb=0;
			setTimeout(clear,2500,check);
	}
	else{
		emailb=1;
	}

}

function validatePwd()
{
	pwd=document.getElementById("pass").value;
	var h=document.getElementById("hdiv5");
	if(pwd.length>=8 && pwd.length<=15)
	{
			clear(h);
			pwdb=1;
	}
	else if(pwd.length<8 || pwd.length>15)
	{
		
		h.style.visibility="visible";
		h.style.color="red";
		h.innerHTML="</br>Password should have mininmum 8 characters and maximum 15 characters";
		pwdb=0;
	}
	
	
}
function erase()
{
	var h=document.getElementById("hdiv5");
	clear(h);
}

var o1={
		
		xhr:new XMLHttpRequest(),
		
		checkusername:function(){
			var uname=document.getElementById("uname").value;
			if(uname!=""){
				console.log("h1");
			this.xhr.onreadystatechange=this.unamestatus;
			this.xhr.open("GET","../php/unamecheck.php?uname="+uname,true);
			this.xhr.send();
			}
		},
		unamestatus:function(){
			if(this.readyState==4 && this.status==200){
				var res=this.responseText;
				/*The JSON.parse() method parses a JSON string, constructing the JavaScript value or object described by the string. */
				console.log(res);
				var resJSON=JSON.parse(res);
				
				if(resJSON.status==0)
				{	console.log("h2");
					var h=document.getElementById("hdiv2");
					h.style.visibility="visible";
					h.style.color="green";
					h.innerHTML="</br>	Valid user name";
					unameb=1;
					setTimeout(clear,2500,h);
					
				}
				else
				{
					console.log("h3");
					var h=document.getElementById("hdiv2");
					h.style.visibility="visible";
					h.style.color="red";
					h.innerHTML="</br>User name exists";
					unameb=0;
					setTimeout(clear,2500,h);
					
				}	
					
			}
		}	
}
