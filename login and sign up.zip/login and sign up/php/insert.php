<?php


$link=mysqli_connect("localhost","root","","inquisitive");
session_start();
extract($_POST);
$_SESSION["uname"]=$uname;


$sql="INSERT INTO `users`(`username`, `name`, `email`, `phoneno`, `password`) VALUES ('$uname','$fname','$email','$pno','$pass')";
 $ret=mysqli_query($link,$sql);
echo $ret; 
?>

<body onload="window.location='../html/dummy.html'">
</body>