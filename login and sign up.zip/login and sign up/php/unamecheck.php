<?php

	extract($_GET);
	$servername = "localhost";
	$username1 = "root";
	$password1 = "";
	$dbname = "inquisitive";
	$link = mysqli_connect($servername, $username1, $password1, $dbname);
	
	$sql="SELECT username FROM users where username='$uname';";
	$ret=mysqli_query($link,$sql);
	
	$rows=mysqli_num_rows($ret);
	
	if($rows>0)
	{
		$res=array('status'=>1);
	}
	else
	{
		$res=array('status'=>0);
	}
	
	echo json_encode($res);
?>



