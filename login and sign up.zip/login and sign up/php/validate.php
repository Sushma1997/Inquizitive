<?php

	extract($_POST);
	session_start();
	$servername = "localhost";
	$username1 = "root";
	$password1 = "";
	$dbname = "inquisitive";
	$link = mysqli_connect($servername, $username1, $password1, $dbname);
	
	$sql="SELECT username FROM users where  username='$uname' and password='$pwd'";
	$ret=mysqli_query($link,$sql);
	
	$rows=mysqli_num_rows($ret);
	
	if($rows>0)
	{
		$_SESSION["uname"]=$uname;
		$res=array('status'=>1);
	}
	else
	{
		$res=array('status'=>0);
	}
	
	echo json_encode($res);
?>



